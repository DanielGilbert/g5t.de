SmallTune - ReadMe
~~~~~~~~~~~~~~~~~~~

Thanks for downloading SmallTune. 


About
~~~~~~~~~~~
SmallTune is a tiny audioplayer for Windows. It doesn't need much space on disk, 
is quite fast and has a single symbol in the notification area.

No waste of space on your desktop.



Features
~~~~~~~~~~~
* Uses SQL-Database for fast handling of the playlist
* Plays Internetstreams
* multilingual
* supports Multimedia Keys on modern keyboards
* supports user-defined hotkeys
* Shuffling
* Filtering
* Repeat the whole playlist
* tiny little visualisation
* no annoying window - hides automaticly
* Native Win32 Application - no .NET or JAVA needed


License
~~~~~~~~~~~
SmallTune is licensed under the MPL v 1.1
For additional details see license.txt


Contact
~~~~~~~~~~~
Web: http://smalltune.net
Mail: me@smalltune.net

Documentation: http://smalltune.net/docs
Forum: http://smalltune.net/forum 